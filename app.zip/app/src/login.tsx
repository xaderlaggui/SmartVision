import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text, StyleSheet, Alert } from 'react-native';

interface Props {
  setCurrentPage: (page: 'home' | 'teacher' | 'personal' | 'login' | 'signup' | 'dashboard') => void;
}

const LoginPage: React.FC<Props> = ({ setCurrentPage }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Check if both email and password fields are filled
    if (!email || !password) {
      Alert.alert('Error', 'Email and password are required!');
    } else {
      // Optionally, validate the email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        Alert.alert('Error', 'Please enter a valid email address!');
      } else {
        // Show a success alert and navigate to dashboard
        Alert.alert('Login Successful', 'Welcome back!', [
          {
            text: 'OK',
            onPress: () => setCurrentPage('dashboard'),
          },
        ]);
      }
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>EMAIL</Text>
      <TextInput
        placeholder="Email"
        style={styles.input}
        value={email}
        onChangeText={setEmail}
      />
      <Text style={styles.text}>PASSWORD</Text>
      <TextInput
        placeholder="Password"
        secureTextEntry
        style={styles.input}
        value={password}
        onChangeText={setPassword}
      />
      
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setCurrentPage('signup')}>
        <Text style={styles.linkText}>Don't have an account? Sign up</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderTopRightRadius: 50,
    borderTopLeftRadius: 50,
    zIndex: +2,
    height: '100%',
    width: '100%',
    alignItems: 'center',
    backgroundColor: '#d7e0ee',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 10,
  },
  input: {
    backgroundColor: 'white',
    width: 350,
    padding: 10,
    marginBottom: 20,
    borderColor:'lightgray',
    borderWidth: 1,
    borderRadius: 50,
  },
  button: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    width: 250,
    alignItems: 'center',
  },
  text: {
    color: 'black',
    textAlign: 'left',
    width: '78%',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  linkText: {
    color: 'black',
    marginTop: 15,
  },
});

export default LoginPage;
