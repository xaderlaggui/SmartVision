import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text, StyleSheet, Alert } from 'react-native';

interface Props {
  setCurrentPage: (page: 'home' | 'teacher' | 'personal' | 'login' | 'signup') => void;
}

const SignupPage: React.FC<Props> = ({ setCurrentPage }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignup = () => {
    // Validate that all fields are filled
    if (!username || !email || !password) {
      Alert.alert('Error', 'All fields are required!');
    } else {
      // Show a registration complete message
      Alert.alert('Registration Complete', 'You have successfully signed up!', [
        {
          text: 'OK',
          onPress: () => setCurrentPage('home'),
        },
      ]);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>USERNAME</Text>
      <TextInput
        placeholder="Username"
        style={styles.input}
        value={username}
        onChangeText={setUsername}
      />
      <Text style={styles.text}>EMAIL</Text>
      <TextInput
        placeholder="Email"
        style={styles.input}
        value={email}
        onChangeText={setEmail}
      />
      <Text style={styles.text}>PASSWORD</Text>
      <TextInput
        placeholder="Password"
        secureTextEntry
        style={styles.input}
        value={password}
        onChangeText={setPassword}
      />
      
      <TouchableOpacity style={styles.button} onPress={handleSignup}>
        <Text style={styles.buttonText}>Sign Up</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setCurrentPage('login')}>
        <Text style={styles.linkText}>Already have an account? Log in</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderTopRightRadius: 50,
    borderTopLeftRadius: 50,
    zIndex: +2,
    height: '100%',
    width: '100%',
    alignItems: 'center',
    backgroundColor: '#d7e0ee',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 10,
  },
  input: {
    backgroundColor: 'white',
    width: 350,
    padding: 10,
    marginBottom: 20,
    borderColor:'lightgray',
    borderWidth: 1,
    borderRadius: 50,
  },
  button: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    width: 250,
    alignItems: 'center',
  },
  text: {
    color: 'black',
    textAlign: 'left',
    width: '78%',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  linkText: {
    color: 'black',
    marginTop: 15,
  },
});

export default SignupPage;
