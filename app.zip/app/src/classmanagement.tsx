import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image, Modal } from 'react-native';

interface Class {
  id: string;
  name: string;
  section: string;
  subject: string;
  schedule: string;
}

interface StudentWork {
  id: string;
  studentName: string;
  work: string;
}

interface Props {
  setCurrentPage: (page: 'home' | 'teacher' | 'personal' | 'login' | 'signup' | 'dashboard' | 'createclass' | 'classmanagement' | 'camera' | 'files') => void;
}

const ClassManagement: React.FC<Props> = ({ setCurrentPage }) => {
  const [classes, setClasses] = useState<Class[]>([
    { id: '1', name: 'Math 101', section: 'A', subject: 'Mathematics', schedule: 'Mon/Wed 10:00 AM' },
    { id: '2', name: 'Physics 102', section: 'B', subject: 'Physics', schedule: 'Tue/Thu 11:00 AM' },
    { id: '3', name: 'Chemistry 101', section: 'A', subject: 'Chemistry', schedule: 'Mon/Fri 9:00 AM' },
    { id: '4', name: 'Biology 103', section: 'C', subject: 'Biology', schedule: 'Wed/Fri 1:00 PM' },
    { id: '5', name: 'English 101', section: 'D', subject: 'English', schedule: 'Mon/Wed/Fri 2:00 PM' },
  ]);

  const [students, setStudents] = useState<StudentWork[]>([
    { id: '1', studentName: 'Xader Laggui', work: 'Completed Assignment 1' },
    { id: '2', studentName: 'Roden Veliganio', work: 'Completed Lab Report' },
    { id: '3', studentName: 'Zane Capalaran', work: 'Submitted Project Draft' },
  ]);

  const [modalVisible, setModalVisible] = useState(false);
  const [selectedClass, setSelectedClass] = useState<Class | null>(null);

  // Handle Create Class
  const handleCreateClass = () => {
    setCurrentPage('createclass');
  };

  // Open Modal to show students and their works
  const handleClassClick = (classItem: Class) => {
    setSelectedClass(classItem);
    setModalVisible(true);
  };

  // Render each class item with individual boxes
  const renderClassItem = ({ item }: { item: Class }) => (
    <TouchableOpacity style={styles.classItem} onPress={() => handleClassClick(item)}>
      <Text style={styles.classText}>{item.name} - {item.section}</Text>
      <Text style={styles.classText}>{item.subject}</Text>
      <Text style={styles.classText}>{item.schedule}</Text>
    </TouchableOpacity>
  );

  // Render student works inside the modal
  const renderStudentItem = ({ item }: { item: StudentWork }) => (
    <View style={styles.studentItem}>
      <Text style={styles.studentText}>{item.studentName}</Text>
      <Text style={styles.studentText}>{item.work}</Text>
    </View>
  );

  return (
    <View style={styles.mainContainer}>
      <View style={styles.container}>
        <Text style={styles.title}>Classes</Text>

        {/* FlatList for Classes */}
        <FlatList
          data={classes}
          renderItem={renderClassItem}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
        />
      </View>

      {/* Bottom Navigation Buttons */}
      <View style={styles.bottomButtonContainer}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => setCurrentPage('dashboard')}
        >
          <Image source={require('../../assets/images/home.png')} style={styles.buttonImage} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button1}
          onPress={() => setCurrentPage('classmanagement')}
        >
          <Image source={require('../../assets/images/document-gear.png')} style={styles.buttonImage} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={() => setCurrentPage('camera')}
        >
          <Image source={require('../../assets/images/camera.png')} style={styles.buttonImage} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={() => setCurrentPage('files')}
        >
          <Image source={require('../../assets/images/folder-open.png')} style={styles.buttonImage} />
        </TouchableOpacity>
      </View>

      {/* Modal to show students and their works */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Students in {selectedClass?.name}</Text>

            <FlatList
              data={students}
              renderItem={renderStudentItem}
              keyExtractor={(item) => item.id}
              showsVerticalScrollIndicator={false}
            />

            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
  },
  container: {
    height: 610,
    width: 350,
    padding: 25,
    backgroundColor: 'white',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 8,
    bottom: 50,
  },
  title: {
    fontSize: 25,
    fontWeight: 'bold',
    marginTop: -30,
    marginBottom: 10,
    marginLeft: -25,
    backgroundColor: 'lightgray',
    width: 350,
    padding: 20,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  classItem: {
    backgroundColor: '#e0e0e0',
    padding: 15,
    marginBottom: 10,
    borderRadius: 10,
    width: '100%',
  },
  classText: {
    fontSize: 16,
    marginBottom: 5,
  },
  bottomButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 25,
    position: 'absolute',
    bottom: -90,
    borderTopWidth: 2,
    borderTopColor: 'black',
    backgroundColor: 'white',
    paddingVertical: 15,
  },
  button: {
    width: 70,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button1: {
    width: 70,
    height: 45,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'gray',
    borderRadius: 30,
  },
  buttonImage: {
    width: 25,
    height: 25,
    resizeMode: 'contain',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    width: 300,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  studentItem: {
    backgroundColor: '#f9f9f9',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    width: '100%',
  },
  studentText: {
    fontSize: 16,
    marginBottom: 5,
  },
  closeButton: {
    backgroundColor: '#4CAF50',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  closeButtonText: {
    color: 'white',
    fontSize: 16,
  },
});

export default ClassManagement;
